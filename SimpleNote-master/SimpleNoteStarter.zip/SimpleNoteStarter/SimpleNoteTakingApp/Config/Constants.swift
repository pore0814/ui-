//
//  Constants.swift
//  SimpleNoteTakingApp
//
//  Created by Hoang Tran on 9/27/16.
//  Copyright © 2016 AppCoda. All rights reserved.
//

let correctUsername = "appcoda"
let correctPassword = "password"

let notificationNewNoteCreated = "NewNoteCreated"
